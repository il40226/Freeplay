// ===== GAME LIST =====
// Add your games here.
// Images go in images/, game HTML files go in games/
//
// Example:
// { id: "snake", name: "Snake", image: "images/snake.png", file: "games/snake.html" },

const GAMES = [
  // Add games here
];

// ===== RENDER GAME GRID =====
function renderGames(filter = "") {
  const grid = document.getElementById("game-grid");
  grid.innerHTML = "";

  const filtered = GAMES.filter(g =>
    g.name.toLowerCase().includes(filter.toLowerCase())
  );

  if (GAMES.length === 0) {
    grid.innerHTML = `
      <div class="empty-msg">
        No games added yet.<br>
        Add game HTML files to <code>games/</code> and thumbnails to <code>images/</code><br>
        then add entries to the GAMES array in <code>js/main.js</code>
      </div>`;
    return;
  }

  if (filtered.length === 0) {
    grid.innerHTML = '<p style="color:#555;grid-column:1/-1;text-align:center;padding:40px;">No games match your search.</p>';
    return;
  }

  filtered.forEach(game => {
    const card = document.createElement("div");
    card.className = "game-card";
    card.onclick = () => openGame(game);
    card.innerHTML = `
      <img src="${game.image}" alt="${game.name}" onerror="this.style.background='#252525';this.alt=''">
      <div class="game-name">${game.name}</div>
    `;
    grid.appendChild(card);
  });
}

// ===== OPEN GAME =====
function openGame(game) {
  const mode = Settings.get("openMode");

  switch (mode) {
    case "newtab":
      // Opens the file:// link in a new tab
      window.open(game.file, "_blank");
      break;

    case "sametab":
      // Replaces the current tab with the game
      window.location.href = game.file;
      break;

    case "iframe":
      // Opens in an iframe overlay (90% wide, 87% tall)
      showIframePlayer(game);
      break;

    case "blank":
      // Opens in an about:blank window with the game embedded
      openInBlank(game);
      break;

    default:
      showIframePlayer(game);
  }
}

// ===== IFRAME PLAYER =====
function showIframePlayer(game) {
  const player = document.getElementById("iframe-player");
  const iframe = document.getElementById("game-iframe");
  const title = document.getElementById("game-title");
  title.textContent = game.name;
  iframe.src = game.file;
  player.classList.add("active");
}

function closeIframePlayer() {
  const player = document.getElementById("iframe-player");
  const iframe = document.getElementById("game-iframe");
  iframe.src = "";
  player.classList.remove("active");
}

// ===== ABOUT:BLANK WINDOW =====
function openInBlank(game) {
  const win = window.open("about:blank", "_blank");
  if (!win) {
    // Popup blocked, fall back to iframe
    showIframePlayer(game);
    return;
  }

  // Build the page inside the about:blank window
  const title = Settings.get("tabDisguise") ? Settings.get("disguiseTitle") : game.name;

  win.document.write(`
    <!DOCTYPE html>
    <html>
    <head>
      <title>${title}</title>
      <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { background: #0f0f0f; display: flex; align-items: center; justify-content: center; height: 100vh; flex-direction: column; }
        .bar { width: 90%; padding: 8px 16px; background: #1a1a1a; display: flex; align-items: center; justify-content: space-between; border-radius: 8px 8px 0 0; border: 1px solid #333; border-bottom: none; }
        .bar span { color: #00e676; font-family: sans-serif; font-size: 14px; font-weight: 600; }
        .bar button { background: #e53935; color: #fff; border: none; padding: 5px 14px; border-radius: 5px; cursor: pointer; font-size: 13px; }
        iframe { width: 90%; height: 87%; border: 1px solid #333; border-radius: 0 0 8px 8px; background: #000; }
      </style>
    </head>
    <body>
      <div class="bar">
        <span>${game.name}</span>
        <button onclick="window.close()">Close</button>
      </div>
      <iframe src="" allowfullscreen></iframe>
      <script>
        // Set iframe src after page loads to handle file:// paths
        document.querySelector('iframe').src = "${new URL(game.file, window.location.href).href}";
      </script>
    </body>
    </html>
  `);
  win.document.close();
}

// ===== INIT =====
document.addEventListener("DOMContentLoaded", () => {
  Settings.init();
  renderGames();

  // Search
  const searchInput = document.getElementById("search-input");
  if (searchInput) {
    searchInput.addEventListener("input", (e) => {
      renderGames(e.target.value);
    });
  }
});
