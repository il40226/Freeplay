// ===== SETTINGS MODULE =====
// Shared between index.html and settings.html
// All settings saved to localStorage under "fp_settings"

const Settings = {
  defaults: {
    tabDisguise: false,
    disguiseTitle: "Google Docs",
    panicKey: "Escape",
    panicURL: "https://classroom.google.com",
    openMode: "iframe" // "newtab", "sametab", "iframe", "blank"
  },

  _data: {},
  _capturingKey: false,
  _defaultTitle: "Freeplay Games",

  init() {
    const saved = localStorage.getItem("fp_settings");
    this._data = saved ? JSON.parse(saved) : { ...this.defaults };
    this.applyTabDisguise();
    this.bindPanicKey();
  },

  get(key) {
    return this._data[key] ?? this.defaults[key];
  },

  set(key, value) {
    this._data[key] = value;
    this.save();
  },

  save() {
    localStorage.setItem("fp_settings", JSON.stringify(this._data));
  },

  // --- Tab Disguise ---
  applyTabDisguise() {
    if (this.get("tabDisguise")) {
      document.title = this.get("disguiseTitle");
    } else {
      document.title = this._defaultTitle;
    }
  },

  // --- Panic Key ---
  bindPanicKey() {
    document.addEventListener("keydown", (e) => {
      // Don't fire panic while capturing a new key in settings
      if (this._capturingKey) return;
      if (e.key === this.get("panicKey")) {
        window.location.replace(this.get("panicURL"));
      }
    });
  }
};
